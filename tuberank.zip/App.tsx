import React, { useState } from 'react';
import InputSection from './components/InputSection';
import ResultsDisplay from './components/ResultsDisplay';
import { generateSeoData } from './services/geminiService';
import { GenerationParams, SeoResult } from './types';
import { Youtube, Zap } from 'lucide-react';

const App: React.FC = () => {
  const [result, setResult] = useState<SeoResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async (params: GenerationParams) => {
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const data = await generateSeoData(params);
      setResult(data);
    } catch (err: any) {
      setError(err.message || 'Something went wrong. Please check your internet or API key.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0f172a] bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]">
      
      {/* Sticky Header */}
      <header className="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-slate-700 shadow-lg">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-red-600 p-2 rounded-lg">
              <Youtube className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
                TubeRank AI
              </h1>
              <p className="text-xs text-slate-400 hidden sm:block">2025 Algorithm Optimizer</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-green-500/10 text-green-400 text-xs font-semibold rounded-full border border-green-500/20 flex items-center gap-1">
              <Zap className="w-3 h-3" />
              AI Powered
            </span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Input */}
        <div className="lg:col-span-5 space-y-6">
          <div className="lg:sticky lg:top-24">
             <InputSection onGenerate={handleGenerate} isLoading={loading} />
             
             {/* Tips Section */}
             <div className="mt-6 p-4 bg-slate-800/50 rounded-xl border border-slate-700/50">
               <h4 className="text-sm font-semibold text-slate-300 mb-2">Why this tool?</h4>
               <ul className="text-xs text-slate-400 space-y-2 list-disc pl-4">
                 <li>Generates metadata for educated & non-educated search styles.</li>
                 <li>Includes regional slang & typos for broader reach.</li>
                 <li>Optimized for Voice Search (Elderly/Kids).</li>
                 <li>Pastes scripts for deep context analysis.</li>
               </ul>
             </div>
          </div>
        </div>

        {/* Right Column: Results */}
        <div className="lg:col-span-7">
          {error && (
            <div className="p-4 bg-red-900/20 border border-red-500/50 text-red-200 rounded-xl mb-6">
              <strong>Error:</strong> {error}
            </div>
          )}

          {!result && !loading && !error && (
            <div className="h-full flex flex-col items-center justify-center text-center p-12 border-2 border-dashed border-slate-700 rounded-2xl opacity-50">
              <Youtube className="w-16 h-16 text-slate-600 mb-4" />
              <h3 className="text-xl font-bold text-slate-300">Ready to go Viral?</h3>
              <p className="text-slate-500 max-w-sm mt-2">
                Enter your video topic or script on the left to generate the ultimate SEO package.
              </p>
            </div>
          )}

          {loading && (
             <div className="space-y-4 animate-pulse">
               <div className="h-24 bg-slate-800 rounded-xl"></div>
               <div className="h-40 bg-slate-800 rounded-xl"></div>
               <div className="h-32 bg-slate-800 rounded-xl"></div>
             </div>
          )}

          {result && <ResultsDisplay data={result} />}
        </div>

      </main>
    </div>
  );
};

export default App;