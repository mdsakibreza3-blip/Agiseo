import React, { useState } from 'react';
import { VideoType, TargetRegion, GenerationParams } from '../types';
import { Youtube, Globe, FileText, Settings2, Sparkles, User, Users } from 'lucide-react';

interface InputSectionProps {
  onGenerate: (params: GenerationParams) => void;
  isLoading: boolean;
}

const InputSection: React.FC<InputSectionProps> = ({ onGenerate, isLoading }) => {
  const [input, setInput] = useState('');
  const [videoType, setVideoType] = useState<VideoType>(VideoType.LONG);
  const [category, setCategory] = useState('Entertainment');
  const [region, setRegion] = useState<TargetRegion>(TargetRegion.INDIA);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    onGenerate({ input, videoType, category, region });
  };

  return (
    <div className="bg-slate-800 rounded-2xl shadow-xl border border-slate-700 overflow-hidden">
      <div className="bg-gradient-to-r from-blue-600 to-violet-600 p-4">
        <h2 className="text-white font-bold flex items-center gap-2 text-lg">
          <Settings2 className="w-5 h-5" />
          Video Setup (2025 Model)
        </h2>
      </div>
      
      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        {/* Toggle Video Type */}
        <div className="flex bg-slate-900 p-1 rounded-lg w-full sm:w-fit">
          <button
            type="button"
            onClick={() => setVideoType(VideoType.LONG)}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-md text-sm font-medium transition-all ${
              videoType === VideoType.LONG ? 'bg-slate-700 text-white shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Long Video
          </button>
          <button
            type="button"
            onClick={() => setVideoType(VideoType.SHORTS)}
            className={`flex-1 sm:flex-none px-4 py-2 rounded-md text-sm font-medium transition-all ${
              videoType === VideoType.SHORTS ? 'bg-red-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Shorts
          </button>
        </div>

        {/* Script/Topic Input */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-slate-300 flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-400" />
            Paste Full Script OR Topic
          </label>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Paste your video script here. The AI will analyze it to find keywords for Men, Women, Elderly, and all demographics..."
            className="w-full h-40 bg-slate-900 border border-slate-700 rounded-lg p-3 text-white placeholder-slate-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            required
          />
          <p className="text-xs text-slate-500 text-right">More detail = Better demographic targeting</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Category */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300 flex items-center gap-2">
              <Youtube className="w-4 h-4 text-red-500" />
              Category
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 outline-none"
            >
              <option value="Entertainment">Comedy / Entertainment</option>
              <option value="Vlog">Vlogging / Lifestyle</option>
              <option value="Gaming">Gaming</option>
              <option value="Tech">Tech / Education</option>
              <option value="News">News / Politics</option>
              <option value="Food">Cooking / Food</option>
              <option value="Motivation">Motivation / Business</option>
              <option value="Kids">Kids Content</option>
            </select>
          </div>

          {/* Region */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300 flex items-center gap-2">
              <Globe className="w-4 h-4 text-green-400" />
              Target Audience
            </label>
            <select
              value={region}
              onChange={(e) => setRegion(e.target.value as TargetRegion)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-blue-500 outline-none"
            >
              {Object.values(TargetRegion).map((r) => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
          </div>
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className={`w-full py-4 rounded-xl font-bold text-lg shadow-lg flex items-center justify-center gap-2 transition-all transform active:scale-95 ${
            isLoading 
              ? 'bg-slate-700 cursor-not-allowed text-slate-400' 
              : 'bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 hover:from-pink-500 hover:to-indigo-500 text-white ring-2 ring-purple-500/20'
          }`}
        >
          {isLoading ? (
            <>
              <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Analyzing Search Psychology...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 fill-yellow-400 text-yellow-100" />
              Generate Viral SEO
            </>
          )}
        </button>
        <p className="text-xs text-center text-slate-500">
          Analyzes behavior of Educated, Uneducated, Elderly, Men, & Women.
        </p>
      </form>
    </div>
  );
};

export default InputSection;