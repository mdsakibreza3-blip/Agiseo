import React, { useState } from 'react';
import { SeoResult } from '../types';
import { Copy, Check, Hash, Tag, Type, AlignLeft, Users, Search } from 'lucide-react';

interface ResultsDisplayProps {
  data: SeoResult;
}

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ data }) => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const handleCopy = (text: string, section: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const CopyButton = ({ text, section }: { text: string; section: string }) => (
    <button
      onClick={() => handleCopy(text, section)}
      className="absolute top-3 right-3 p-2 bg-slate-700/50 hover:bg-blue-600 rounded-lg transition-colors group"
      title="Copy to clipboard"
    >
      {copiedSection === section ? (
        <Check className="w-4 h-4 text-green-400" />
      ) : (
        <Copy className="w-4 h-4 text-slate-300 group-hover:text-white" />
      )}
    </button>
  );

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      
      {/* Demographic Intelligence Grid */}
      <div className="bg-gradient-to-br from-indigo-900/50 to-slate-900 border border-indigo-500/30 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-indigo-500/20 flex items-center gap-2 bg-indigo-950/30">
          <Users className="w-5 h-5 text-indigo-400" />
          <h3 className="font-bold text-indigo-100">Deep Audience Analysis (How People Search)</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
          {data.demographicInsights.map((insight, idx) => (
            <div key={idx} className="bg-slate-800/50 p-4 rounded-lg border border-slate-700/50 hover:border-indigo-500/50 transition-colors">
              <div className="flex items-center gap-2 mb-2">
                <Search className="w-4 h-4 text-blue-400" />
                <h4 className="font-semibold text-slate-200 text-sm">{insight.segment}</h4>
              </div>
              <p className="text-xs text-slate-400 mb-3 italic">"{insight.behavior}"</p>
              <div className="flex flex-wrap gap-1.5">
                {insight.suggestedKeywords.map((kw, kIdx) => (
                  <span key={kIdx} className="text-[10px] px-2 py-1 bg-indigo-500/10 text-indigo-300 rounded border border-indigo-500/20">
                    {kw}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Titles */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden relative">
        <div className="p-4 border-b border-slate-700 bg-slate-800/50 flex items-center gap-2">
          <Type className="w-5 h-5 text-pink-500" />
          <h3 className="font-bold text-white">Viral Titles (2025 Optimized)</h3>
        </div>
        <div className="p-4 space-y-3">
          {data.titles.map((title, idx) => (
            <div key={idx} className="group relative">
               <div className="bg-slate-900 p-3 rounded-lg border border-slate-700 pr-10 hover:border-blue-500 transition-colors">
                 <span className="text-slate-200 font-medium">{title}</span>
               </div>
               <button
                  onClick={() => handleCopy(title, `title-${idx}`)}
                  className="absolute right-2 top-2 p-1.5 hover:bg-slate-700 rounded text-slate-400 hover:text-white"
                >
                  {copiedSection === `title-${idx}` ? <Check className="w-4 h-4 text-green-400"/> : <Copy className="w-4 h-4"/>}
               </button>
            </div>
          ))}
        </div>
      </div>

      {/* Description */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden relative">
        <div className="p-4 border-b border-slate-700 bg-slate-800/50 flex items-center gap-2">
          <AlignLeft className="w-5 h-5 text-blue-500" />
          <h3 className="font-bold text-white">SEO Description</h3>
        </div>
        <div className="p-4">
          <div className="bg-slate-900 p-4 rounded-lg border border-slate-700 text-slate-300 text-sm whitespace-pre-wrap font-mono leading-relaxed h-64 overflow-y-auto">
            {data.description}
          </div>
        </div>
        <CopyButton text={data.description} section="desc" />
      </div>

      {/* Tags */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden relative">
        <div className="p-4 border-b border-slate-700 bg-slate-800/50 flex items-center gap-2">
          <Tag className="w-5 h-5 text-green-500" />
          <h3 className="font-bold text-white">Keywords & Tags</h3>
        </div>
        <div className="p-4">
          <div className="bg-slate-900 p-4 rounded-lg border border-slate-700 text-slate-300 text-sm font-mono break-words">
            {data.tags.join(', ')}
          </div>
        </div>
        <CopyButton text={data.tags.join(',')} section="tags" />
      </div>

      {/* Hashtags */}
      <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden relative">
        <div className="p-4 border-b border-slate-700 bg-slate-800/50 flex items-center gap-2">
          <Hash className="w-5 h-5 text-purple-500" />
          <h3 className="font-bold text-white">Hashtags</h3>
        </div>
        <div className="p-4">
           <div className="flex flex-wrap gap-2">
             {data.hashtags.map((tag, i) => (
               <span key={i} className="px-3 py-1 bg-purple-900/30 text-purple-300 border border-purple-500/30 rounded-full text-sm">
                 {tag.startsWith('#') ? tag : `#${tag}`}
               </span>
             ))}
           </div>
        </div>
        <CopyButton text={data.hashtags.map(t => t.startsWith('#') ? t : `#${t}`).join(' ')} section="hashtags" />
      </div>

      {/* Copy All Button */}
      <button
        onClick={() => {
            const allText = `TITLES:\n${data.titles.join('\n')}\n\nDESCRIPTION:\n${data.description}\n\nTAGS:\n${data.tags.join(',')}\n\nHASHTAGS:\n${data.hashtags.map(t => t.startsWith('#') ? t : `#${t}`).join(' ')}`;
            handleCopy(allText, 'all');
        }}
        className="w-full py-4 bg-white text-slate-900 font-bold rounded-xl shadow-lg hover:bg-slate-200 transition-colors flex items-center justify-center gap-2 safe-bottom"
      >
        {copiedSection === 'all' ? <Check className="w-5 h-5 text-green-600"/> : <Copy className="w-5 h-5"/>}
        Copy Complete SEO Package
      </button>

    </div>
  );
};

export default ResultsDisplay;