import { GoogleGenAI, Type, Schema } from "@google/genai";
import { GenerationParams, VideoType, SeoResult } from "../types";

// Initialize the client. The API_KEY is injected by the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const RESPONSE_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    titles: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "3 highly clickable, viral-optimized titles."
    },
    description: {
      type: Type.STRING,
      description: "A full, algorithm-friendly video description with keywords woven in naturally."
    },
    tags: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Comma-separated list of keywords optimized for various demographics."
    },
    hashtags: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Relevant hashtags including high volume and niche tags."
    },
    demographicInsights: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          segment: { type: Type.STRING, description: "The demographic group (e.g., 'Elderly', 'Gen Z', 'Rural/Uneducated')." },
          behavior: { type: Type.STRING, description: "Description of how this specific group searches for this topic." },
          suggestedKeywords: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Specific keywords this group uses." }
        },
        required: ["segment", "behavior", "suggestedKeywords"]
      },
      description: "Detailed breakdown of search behaviors for different user groups."
    }
  },
  required: ["titles", "description", "tags", "hashtags", "demographicInsights"]
};

export const generateSeoData = async (params: GenerationParams): Promise<SeoResult> => {
  const { input, videoType, category, region } = params;

  const systemInstruction = `
    You are the world's leading YouTube SEO Expert & Cultural Anthropologist for the 2025 Algorithm. 
    Your goal is to maximize Click-Through Rate (CTR) and Watch Time by understanding deep search psychology across all user types.

    INPUT CONTEXT:
    - Video Type: ${videoType}
    - Category: ${category}
    - Target Region: ${region}

    CRITICAL DEMOGRAPHIC & SEARCH BEHAVIOR ANALYSIS (MUST DO):
    You must analyze the input script/topic and generate metadata that targets specific behaviors:

    1. **Educated / High-Tech Users**: They search using English, precise terms, and fast typing.
    2. **Uneducated / Low-Literacy Users**: They use voice search, wrong spellings, simple local words (Hinglish/Urdu-English), and question-based phrases ("video dikhao").
    3. **Elderly / Senior Citizens**: They type slowly, use very polite or long sentences, or use voice commands like "Please show me funny video".
    4. **Gen Z / Kids**: They use slang, short forms, emojis, and trend-based keywords.
    5. **Gender Specifics**: 
       - How do MEN search for this topic?
       - How do WOMEN search for this topic? (Analyze if there is a difference in intent or keywords).

    OUTPUT REQUIREMENTS:
    1. **Viral Titles**: 
       - Option 1: High CTR / Shocking / Curiosity.
       - Option 2: Search Optimized (Keywords first).
       - Option 3: Story/Emotional based.
    2. **Description**: 
       - 1st paragraph: Hook with main keywords.
       - 2nd paragraph: Summary of the script/content.
       - 3rd paragraph: Call to Action.
    3. **Tags**: Mix of broad (high volume), specific (long-tail), and Misspelled/Voice-search tags.
    4. **Hashtags**: 3 Broad, 3 Niche, 2 Trending.
    5. **Demographic Insights**: Explicitly explain the strategy for at least 4 different groups (e.g., "Rural Audience", "Female Audience", etc.) and the keywords targeting them.
  `;

  const prompt = `
    Analyze the following video input (Script or Topic):
    """
    ${input}
    """
    
    Generate the ultimate 2025 YouTube SEO package for this content. 
    Focus on how different people (Villagers vs City people, Kids vs Elders) would search for this specific script.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: RESPONSE_SCHEMA,
        temperature: 0.75, // Slightly higher for creative demographic analysis
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response generated from AI.");
    }

    const jsonResponse = JSON.parse(text) as SeoResult;
    return jsonResponse;

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to generate SEO data. Please try again.");
  }
};