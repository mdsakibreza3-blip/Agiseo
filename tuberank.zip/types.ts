export enum VideoType {
  LONG = 'Long Form',
  SHORTS = 'YouTube Shorts'
}

export enum TargetRegion {
  GLOBAL = 'Global / International',
  INDIA = 'India',
  PAKISTAN = 'Pakistan',
  USA = 'USA/Western',
  ASIA = 'Asia General'
}

export interface DemographicInsight {
  segment: string; // e.g. "Elderly Users", "Casual/Uneducated", "Tech-Savvy"
  behavior: string; // How they search
  suggestedKeywords: string[]; // Specific keywords for this group
}

export interface SeoResult {
  titles: string[];
  description: string;
  tags: string[];
  hashtags: string[];
  demographicInsights: DemographicInsight[]; // New detailed breakdown
}

export interface GenerationParams {
  input: string; // Script or Topic
  videoType: VideoType;
  category: string;
  region: TargetRegion;
}